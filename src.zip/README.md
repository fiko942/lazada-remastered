```
Fix the puppeteer-extra error on compile follow the link bellow
```

https://github.com/berstend/puppeteer-extra/issues/93#issuecomment-712364816
